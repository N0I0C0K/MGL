#include"MGL_CODE_AREA.h"

Code::Code(string name,string code, string precode)
{
	this->name = name;
	this->bytecode = code;
	this->bytePrecode = precode;
}